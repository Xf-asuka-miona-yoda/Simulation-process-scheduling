package os;

public class Addr {
	int pageid;
	int pianyi;
	int trueaddr;
	
	public Addr()
	{
		pageid = -1;
		pianyi = -1;
		trueaddr = -1;
	}
}
